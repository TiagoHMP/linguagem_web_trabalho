class Cliente:
    id = ''
    nome = ''
    apelido = ''
    cnpj = ''


    def __init__(self, id = '',nome = '', apelido = '', cnpj = ''):
        self.id = id
        self.nome = nome
        self.apelido = apelido
        self.cnpj = cnpj
